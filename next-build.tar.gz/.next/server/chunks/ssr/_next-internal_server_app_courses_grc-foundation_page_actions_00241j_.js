module.exports=[12133,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_courses_grc-foundation_page_actions_00241j_.js.map