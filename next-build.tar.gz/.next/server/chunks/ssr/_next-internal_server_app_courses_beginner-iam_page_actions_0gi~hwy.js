module.exports=[66335,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_courses_beginner-iam_page_actions_0gi~hwy.js.map