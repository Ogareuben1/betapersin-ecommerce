module.exports=[39176,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_courses_iam_page_actions_0n4bio~.js.map