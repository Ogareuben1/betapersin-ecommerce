1:"$Sreact.fragment"
2:I[59150,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0eewamb49pw7k.js","/_next/static/chunks/0b7ewch4xsjba.js","/_next/static/chunks/15940g-vtuwrj.js"],"default"]
3:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0eewamb49pw7k.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0b7ewch4xsjba.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/15940g-vtuwrj.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"IF8hsoYEExWIUA4us1a8Y"}
5:null
