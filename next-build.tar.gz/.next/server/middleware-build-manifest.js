globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/0a_YxXgKveoCeQE5vXttf/_buildManifest.js",
    "static/0a_YxXgKveoCeQE5vXttf/_ssgManifest.js",
    "static/0a_YxXgKveoCeQE5vXttf/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0dplp6vf-6guo.js",
    "static/chunks/0t~alnn~v6duj.js",
    "static/chunks/0z4t28s6f-niz.js",
    "static/chunks/0ykblk.o3k9.4.js",
    "static/chunks/turbopack-147lz76~q~e9t.js"
  ]
};
